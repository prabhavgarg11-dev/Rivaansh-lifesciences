/**
 * script.js — Rivaansh Lifesciences Frontend Engine
 * Features: API fetch, search/filter, cart (localStorage), orders, modal
 */

const API = 'http://localhost:5000';

// ── State ──────────────────────────────────────────────────────────────────
let _allProducts   = [];   // full catalogue from API
let _filtered      = [];   // currently shown on products page
let _currentCat    = 'all';
let _currentSearch = '';
let _currentSort   = 'default';
let _cart          = JSON.parse(localStorage.getItem('rv_cart') || '[]');
let _orders        = JSON.parse(localStorage.getItem('rv_orders') || '[]');
let _cartOpen      = false;

// ── DOM READY ──────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    attachSearch();
    renderCart();
    updateCartBadge();
    renderOrders();
    await loadProducts();
    hideLoader();
});

// ── LOADER ─────────────────────────────────────────────────────────────────
function hideLoader() {
    const l = document.getElementById('loader');
    if (l) { l.classList.add('hidden'); }
}

// ── FETCH PRODUCTS ─────────────────────────────────────────────────────────
async function loadProducts() {
    try {
        const res = await fetch(`${API}/api/products`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        _allProducts = await res.json();
        if (!Array.isArray(_allProducts) || !_allProducts.length) {
            throw new Error('No products returned');
        }
        _filtered = [..._allProducts];
        renderHome();
        renderProductsPage();
    } catch (err) {
        console.error('❌ Fetch error:', err.message);
        showError();
    }
}

// ── RENDER HOME (trending, first 8) ───────────────────────────────────────
function renderHome() {
    const grid = document.getElementById('homeGrid');
    if (!grid) return;
    const featured = _allProducts.slice(0, 8);
    grid.innerHTML = featured.map(p => cardHTML(p)).join('');
    animateCards(grid);
}

// ── RENDER PRODUCTS PAGE ───────────────────────────────────────────────────
function renderProductsPage() {
    const grid    = document.getElementById('allGrid');
    const counter = document.getElementById('productCount');
    const noRes   = document.getElementById('noResults');
    if (!grid) return;

    if (!_filtered.length) {
        grid.innerHTML = '';
        if (noRes) noRes.classList.remove('hidden');
        if (counter) counter.textContent = '0 products found';
        return;
    }
    if (noRes) noRes.classList.add('hidden');
    if (counter) counter.textContent = `${_filtered.length} product${_filtered.length !== 1 ? 's' : ''} found`;

    grid.innerHTML = _filtered.map(p => cardHTML(p)).join('');
    animateCards(grid);
}

// ── CARD HTML ──────────────────────────────────────────────────────────────
function cardHTML(p) {
    const inCart   = _cart.find(i => i.id === p.id);
    const discount = p.originalPrice ? Math.round((1 - p.price / p.originalPrice) * 100) : 0;
    const badgeHTML = p.badge ? `<div class="card-badge">${p.badge}</div>` : '';
    const rxHTML    = p.prescriptionRequired ? `<div class="rx-flag">Rx</div>` : '';

    const addBtnHTML = inCart
        ? `<div class="qty-ctrl">
                <button onclick="event.stopPropagation(); updateQty(${p.id}, -1)">−</button>
                <span>${inCart.qty}</span>
                <button onclick="event.stopPropagation(); updateQty(${p.id}, +1)">+</button>
           </div>`
        : `<button class="add-btn" onclick="event.stopPropagation(); addToCart(${p.id})">
                <i class="fa fa-plus"></i> Add
           </button>`;

    return `
    <div class="product-card" onclick="openModal(${p.id})">
        <div class="card-img-wrap">
            <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/400x300/e0f5f2/0a7c6e?text=Rivaansh'">
            ${badgeHTML}
            ${rxHTML}
        </div>
        <div class="card-body">
            <div class="card-brand">${p.brand || 'Rivaansh'}</div>
            <div class="card-name">${p.name}</div>
            <div class="card-comp">${p.composition}</div>
            <div class="card-footer">
                <div class="card-price-wrap">
                    <div class="card-price">
                        ₹${p.price}
                        ${discount > 0 ? `<span class="card-disc">${discount}% off</span>` : ''}
                    </div>
                    ${p.originalPrice ? `<div class="card-orig">₹${p.originalPrice}</div>` : ''}
                </div>
                ${addBtnHTML}
            </div>
        </div>
    </div>`;
}

// ── ANIMATE CARDS ──────────────────────────────────────────────────────────
function animateCards(grid) {
    const cards = grid.querySelectorAll('.product-card');
    cards.forEach((c, i) => {
        c.style.animationDelay = `${i * 0.04}s`;
    });
}

// ── FILTER BY CATEGORY ─────────────────────────────────────────────────────
window.filterCat = function(cat, btn) {
    _currentCat = cat;
    // Update active button
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    applyFilters();
};

// ── SORT ───────────────────────────────────────────────────────────────────
window.sortProducts = function(val) {
    _currentSort = val;
    applyFilters();
};

// ── APPLY FILTERS + SORT ───────────────────────────────────────────────────
function applyFilters() {
    let list = [..._allProducts];

    if (_currentCat && _currentCat !== 'all') {
        list = list.filter(p => p.category?.toLowerCase() === _currentCat);
    }
    if (_currentSearch) {
        const q = _currentSearch.toLowerCase();
        list = list.filter(p =>
            p.name?.toLowerCase().includes(q) ||
            p.brand?.toLowerCase().includes(q) ||
            p.composition?.toLowerCase().includes(q) ||
            p.category?.toLowerCase().includes(q)
        );
    }
    if (_currentSort === 'price-asc')  list.sort((a, b) => a.price - b.price);
    if (_currentSort === 'price-desc') list.sort((a, b) => b.price - a.price);
    if (_currentSort === 'name-asc')   list.sort((a, b) => a.name.localeCompare(b.name));

    _filtered = list;
    renderProductsPage();
}

// ── SEARCH ─────────────────────────────────────────────────────────────────
function attachSearch() {
    const input = document.getElementById('searchInput');
    const clear = document.getElementById('searchClear');
    if (!input) return;

    let debounce;
    input.addEventListener('input', () => {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
            _currentSearch = input.value.trim();
            if (clear) clear.style.display = _currentSearch ? 'block' : 'none';
            if (_currentSearch) showPage('products');
            applyFilters();
        }, 280);
    });
}

window.clearSearch = function() {
    const input = document.getElementById('searchInput');
    const clear = document.getElementById('searchClear');
    if (input) input.value = '';
    if (clear) clear.style.display = 'none';
    _currentSearch = '';
    applyFilters();
};

// ── MODAL ──────────────────────────────────────────────────────────────────
window.openModal = function(id) {
    const p = _allProducts.find(x => x.id === id);
    if (!p) return;

    const discount = p.originalPrice ? Math.round((1 - p.price / p.originalPrice) * 100) : 0;
    const inCart   = _cart.find(i => i.id === p.id);

    const addBtn = inCart
        ? `<button class="modal-add-btn" style="background:var(--su);" onclick="closeModalDirect(); toggleCart()"><i class="fa fa-bag-shopping"></i> View in Cart (${inCart.qty})</button>`
        : `<button class="modal-add-btn" onclick="addToCart(${p.id}); closeModalDirect()"><i class="fa fa-cart-plus"></i> Add to Cart</button>`;

    document.getElementById('modalContent').innerHTML = `
        <img class="modal-img" src="${p.image}" alt="${p.name}" onerror="this.src='https://placehold.co/700x260/e0f5f2/0a7c6e?text=Rivaansh'">
        <div class="modal-body">
            <div class="modal-brand">${p.brand}</div>
            <h2 class="modal-name">${p.name}</h2>
            <div class="modal-comp"><i class="fa fa-flask-vial"></i> ${p.composition}</div>
            <p class="modal-desc">${p.description || 'Clinical formulation by Rivaansh Lifesciences.'}</p>
            <div class="modal-price-row">
                <span class="modal-price">₹${p.price}</span>
                ${p.originalPrice ? `<span class="modal-orig">₹${p.originalPrice}</span>` : ''}
                ${discount > 0 ? `<span class="modal-save">Save ${discount}%</span>` : ''}
            </div>
            ${p.prescriptionRequired ? `<div class="modal-rx-warn"><i class="fa fa-prescription-bottle-medical"></i> This product requires a valid prescription.</div>` : ''}
            <div class="modal-actions">
                ${addBtn}
                <button class="modal-close-btn" onclick="closeModalDirect()">Close</button>
            </div>
        </div>`;

    const overlay = document.getElementById('modal');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
};

window.closeModal = function(e) {
    if (e.target === document.getElementById('modal')) closeModalDirect();
};

window.closeModalDirect = function() {
    document.getElementById('modal').classList.remove('open');
    document.body.style.overflow = '';
};

// ── CART LOGIC ─────────────────────────────────────────────────────────────
window.addToCart = function(id) {
    const p = _allProducts.find(x => x.id === id);
    if (!p) return;
    const existing = _cart.find(i => i.id === id);
    if (existing) {
        existing.qty = Math.min(existing.qty + 1, 20);
    } else {
        _cart.push({ id: p.id, name: p.name, price: p.price, image: p.image, qty: 1, brand: p.brand });
    }
    saveCart();
    toast(`${p.name} added to cart`, 'success');
    refreshProductGrids();
};

window.removeFromCart = function(id) {
    _cart = _cart.filter(i => i.id !== id);
    saveCart();
    refreshProductGrids();
};

window.updateQty = function(id, delta) {
    const item = _cart.find(i => i.id === id);
    if (!item) return;
    item.qty = Math.max(0, Math.min(item.qty + delta, 20));
    if (item.qty === 0) _cart = _cart.filter(i => i.id !== id);
    saveCart();
    refreshProductGrids();
};

function saveCart() {
    localStorage.setItem('rv_cart', JSON.stringify(_cart));
    renderCart();
    updateCartBadge();
}

function refreshProductGrids() {
    renderHome();
    renderProductsPage();
}

function updateCartBadge() {
    const total = _cart.reduce((s, i) => s + i.qty, 0);
    const badge = document.getElementById('cartBadge');
    if (!badge) return;
    if (total > 0) {
        badge.textContent = total > 99 ? '99+' : total;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

function renderCart() {
    const container = document.getElementById('cartItems');
    if (!container) return;

    if (!_cart.length) {
        container.innerHTML = `<div class="cart-empty"><i class="fa fa-bag-shopping"></i><p>Your cart is empty</p></div>`;
        document.getElementById('cartSubtotal').textContent = '₹0';
        document.getElementById('cartDelivery').textContent = '₹49';
        document.getElementById('cartTotal').textContent = '₹49';
        return;
    }

    container.innerHTML = _cart.map(item => `
        <div class="cart-item">
            <img class="cart-item-img" src="${item.image}" alt="${item.name}" onerror="this.src='https://placehold.co/50x50/e0f5f2/0a7c6e?text=R'">
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">₹${item.price * item.qty}</div>
                <div class="cart-item-qty">
                    <button onclick="updateQty(${item.id}, -1)">−</button>
                    <span>${item.qty}</span>
                    <button onclick="updateQty(${item.id}, +1)">+</button>
                </div>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart(${item.id})"><i class="fa fa-trash"></i></button>
        </div>
    `).join('');

    const sub      = _cart.reduce((s, i) => s + i.price * i.qty, 0);
    const delivery = sub >= 499 ? 0 : 49;
    const total    = sub + delivery;

    document.getElementById('cartSubtotal').textContent = `₹${sub}`;
    document.getElementById('cartDelivery').textContent = delivery === 0 ? 'FREE' : `₹${delivery}`;
    document.getElementById('cartTotal').textContent    = `₹${total}`;
}

// ── CART DRAWER ────────────────────────────────────────────────────────────
window.toggleCart = function() {
    _cartOpen = !_cartOpen;
    document.getElementById('cartDrawer').classList.toggle('open', _cartOpen);
    document.getElementById('cartOverlay').classList.toggle('open', _cartOpen);
    document.body.style.overflow = _cartOpen ? 'hidden' : '';
};

// ── CHECKOUT ───────────────────────────────────────────────────────────────
window.checkout = async function() {
    if (!_cart.length) { toast('Your cart is empty', 'error'); return; }

    const sub      = _cart.reduce((s, i) => s + i.price * i.qty, 0);
    const delivery = sub >= 499 ? 0 : 49;

    try {
        const res = await fetch(`${API}/api/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                items: _cart.map(i => ({ productId: i.id, name: i.name, quantity: i.qty, price: i.price })),
                address: 'Rivaansh Hub, Jaipur, Rajasthan',
                phone: '9800000000',
                totalAmount: sub + delivery
            })
        });

        const data = await res.json();
        if (data.success || data.order) {
            const order = {
                id: data.order?._id || 'ORD' + Date.now(),
                items: [..._cart],
                totalAmount: sub + delivery,
                status: 'confirmed',
                date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
            };
            _orders.unshift(order);
            localStorage.setItem('rv_orders', JSON.stringify(_orders));
            _cart = [];
            saveCart();
            renderOrders();
            if (_cartOpen) toggleCart();
            toast('🎉 Order placed successfully!', 'success');
            showPage('orders');
        } else {
            toast('Order failed. Please try again.', 'error');
        }
    } catch (err) {
        console.error('Checkout error:', err);
        toast('Could not connect to server.', 'error');
    }
};

// ── ORDERS ─────────────────────────────────────────────────────────────────
function renderOrders() {
    const container = document.getElementById('ordersList');
    if (!container) return;

    if (!_orders.length) {
        container.innerHTML = `
            <div class="empty-orders">
                <div class="empty-icon"><i class="fa fa-clipboard-list"></i></div>
                <h3>No orders yet</h3>
                <p>Your confirmed purchases will appear here.</p>
                <button class="btn-primary" onclick="showPage('products')">Start Shopping</button>
            </div>`;
        return;
    }

    container.innerHTML = _orders.map(o => `
        <div class="order-card">
            <div class="order-top">
                <div>
                    <div class="order-id">Order #${String(o.id).slice(-8).toUpperCase()}</div>
                    <div class="order-date">${o.date}</div>
                </div>
                <span class="order-status ${o.status === 'delivered' ? 'delivered' : ''}">${(o.status || 'Confirmed').toUpperCase()}</span>
            </div>
            <p class="order-meta"><strong>${o.items?.length || 0} item(s)</strong> ordered</p>
            <p class="order-total">Total: ₹${o.totalAmount}</p>
            <details style="margin-top:10px; cursor:pointer;">
                <summary style="font-size:.82rem; font-weight:700; color:var(--tl); user-select:none;">View Items</summary>
                <div style="margin-top:8px; display:flex; flex-direction:column; gap:6px;">
                    ${(o.items || []).map(i => `
                        <div style="display:flex; justify-content:space-between; font-size:.8rem; padding:6px 10px; background:var(--bg); border-radius:6px;">
                            <span>${i.name} <strong>×${i.qty || i.quantity || 1}</strong></span>
                            <span style="font-weight:700;">₹${(i.price || 0) * (i.qty || i.quantity || 1)}</span>
                        </div>`).join('')}
                </div>
            </details>
        </div>
    `).join('');
}

// ── PAGE NAVIGATION ────────────────────────────────────────────────────────
window.showPage = function(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const el = document.getElementById(page + 'Page');
    if (el) el.classList.add('active');

    // Sync nav
    document.querySelectorAll('.nav-link').forEach(l => {
        l.classList.toggle('active', l.dataset.page === page);
    });
    document.querySelectorAll('.bnav-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.page === page);
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
};

// ── TOAST ──────────────────────────────────────────────────────────────────
function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `toast show ${type}`;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('show'), 2800);
}
window.st = toast; // global alias for other modules

// ── ERROR STATE ────────────────────────────────────────────────────────────
function showError() {
    const grids = [document.getElementById('homeGrid'), document.getElementById('allGrid')];
    grids.forEach(g => {
        if (g) g.innerHTML = `
            <div style="grid-column:1/-1; text-align:center; padding:60px 20px; color:var(--tm);">
                <i class="fa fa-circle-exclamation" style="font-size:2.5rem; color:#f59e0b; display:block; margin-bottom:12px;"></i>
                <strong style="font-size:1rem; color:var(--nv);">Unable to load products</strong>
                <p style="font-size:.85rem; margin-top:6px;">Make sure the backend server is running at <code>http://localhost:5000</code></p>
                <button onclick="location.reload()" style="margin-top:16px; background:var(--tl); color:#fff; border:none; padding:10px 22px; border-radius:50px; font-weight:700; cursor:pointer;">
                    <i class="fa fa-rotate-right"></i> Retry
                </button>
            </div>`;
    });
    const counter = document.getElementById('productCount');
    if (counter) counter.textContent = 'Backend server not reachable';
}
