# Rivaansh Lifesciences — Pharmacy eCommerce Website

## 📁 Project Structure
```
rivaansh/
│
├── backend/
│   ├── server.js            ← Express API server (port 5000)
│   ├── package.json
│   └── data/
│       └── products.json    ← 12 healthcare products
│
└── frontend/
    ├── index.html           ← Main SPA
    ├── style.css            ← Premium design system
    └── script.js            ← App logic (fetch, cart, search, orders)
```

---

## 🚀 Quick Start

### Step 1 — Start the Backend API
```bash
cd backend
npm install
npm start
```
Server runs at: **http://localhost:5000**

Verify it works:
- http://localhost:5000/api/products
- http://localhost:5000/api/products/1

### Step 2 — Serve the Frontend
Option A (recommended):
```bash
cd frontend
npx serve . -p 3000
```
Visit: **http://localhost:3000**

Option B — Open directly:
Just open `frontend/index.html` in your browser.
> ⚠️ Direct file open may have CORS issues with fetch. Use a server (Option A).

---

## ✅ What's Included

### Backend
- `GET /api/products` — All products (supports `?search=` and `?category=` query params)
- `GET /api/products/:id` — Single product by ID
- `POST /api/orders` — Place an order (logs to console)
- CORS enabled for all origins
- JSON-file database (no MongoDB needed)

### Frontend
- **Homepage**: Hero, trending products, category cards, trust strip
- **Products Page**: Full catalogue with search + category filter + sort
- **Product Modal**: Full details, composition, discount, Rx warning
- **Cart Drawer**: Slide-in cart with add/remove/qty update
- **Orders Page**: Order history stored in localStorage
- **Checkout**: Calls backend API, stores order locally
- **Responsive**: Mobile-first with sticky header + bottom nav
- **Error Handling**: Retry button if backend is offline

### Cart Features
- Stored in `localStorage` (persists across refreshes)
- Free delivery above ₹499
- Quantity controls on every product card
- Total calculation with delivery fee

---

## 🛠️ Requirements
- Node.js 16+
- npm

No MongoDB, no database setup needed!

---

## 🎨 Design System
- **Fonts**: Syne (display) + DM Sans (body)
- **Colors**: Deep Navy `#0d1f3c` + Clinical Teal `#0a7c6e` + Coral Red `#e8472a`
- **Theme**: Clinical Luxury — precise, premium, trustworthy
